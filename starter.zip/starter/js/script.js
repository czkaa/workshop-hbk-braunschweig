document.onload = function (e) {
  console.log('Hello World!');
};
